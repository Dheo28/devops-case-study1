# DevOps Case Study

Studi kasus untuk DevOps:
- Docker
- Docker Compose
- CI/CD
- Terraform
- Kubernetes
